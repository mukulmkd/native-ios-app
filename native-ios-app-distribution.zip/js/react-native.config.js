module.exports = {
  dependencies: {},
};

